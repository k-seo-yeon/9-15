
import card1 from './inscard1.png';
import card2 from './inscard2.png';
import card3 from './inscard3.png';
import card4 from './inscard4.png';

const inspirationCards = [
  card1,
  card2,
  card3,
  card4,
];

export default inspirationCards;
