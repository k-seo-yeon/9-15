// 실제 프로젝트 설정 값. 민감정보이므로 VCS에 커밋하지 않는 것을 권장합니다.
// 필요 시 .gitignore에 추가하거나 환경변수로 관리하세요.

export const firebaseConfig = {
  apiKey: "AIzaSyCyOMthpGpzeolCoob_MytHn5PddssUJj4",
  authDomain: "it-project-4a71c.firebaseapp.com",
  projectId: "it-project-4a71c",
  storageBucket: "it-project-4a71c.firebasestorage.app",
  messagingSenderId: "1085607018365",
  appId: "1:1085607018365:web:db74f7b468090708af5614",
  measurementId: "G-EBCG7LV1VB"
};



